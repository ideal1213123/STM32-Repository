#include <cstddef>
#include <cmath>
#include <ctime>
#include <cstring>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#define HQ_INLINE  inline
#define SAFE_DELETS(p) if(p){ delete[] p; p=0; }
#define RAND_INI srand(0)
#define RAND_ONE ( rand()*(1.0/(RAND_MAX+1.0)) )
#define RAND_INTEGER(v) (rand()%v)
#define MAX(a,b) (a>b?a:b)
#define MIN(a,b) (a>b?b:a)
#define MAX3(a,b,c) (a>b?MAX(a,c):MAX(b,c))
#define MIN3(a,b,c) (a<b?MIN(a,c):MIN(b,c))
#define CLIP(v,d,u) (v<u?(v<d?d:v):u)
#define ENCODE_POS(r,c) ( ((r)&0xFFFF)<<16 | ((c)&0xFFFF) )
#define DECODE_POS(pos,r,c)  do{ r=(pos>>16 & 0xFFFF);c = pos & 0xFFFF; }while(0)
#define RANGE(v,s,e) for(int v=s; v<e; ++v )

#define HQ_PI 3.1415926535897932384626433832795
#define ANG_RD 57.295779513082320876798154814105
#define ANG_DR 0.01745329251994329576923690768489


enum NET_ACTIVE_TYPE{
    NET_ACTIVE_NULL,
    NET_ACTIVE_STRAIGHT,
    NET_ACTIVE_SIGMOID,
    NET_ACTIVE_TANH,
    NET_ACTIVE_TANH2,
    NET_ACTIVE_NUM,
};

#define straight(x)  (x)
#define dstraight(x) (1)
#define sigmoid(y)  ( 1.0/(1.0 + exp(-y)) )
#define dsigmoid(z) ( z*(1.0 - z) )

#define ActiveFuncProto(f)    DataType f(DataType y)
#define DeActiveFuncProto(f)  DataType f(DataType y,DataType z)
#define MAKE_ACTFUNC_VAR(var,DT,Act)\
        typename ActFunc<DT>::PtrFunActive var = ActFunc<DT>::GetActiveFunc(Act)
#define MAKE_DEACTFUNC_VAR(var,DT,Act)\
        typename ActFunc<DT>::PtrFunDeActive var = ActFunc<DT>::GetDeActiveFunc(Act)


template<typename DataType>
class ActFunc{
public:
	typedef ActiveFuncProto( (*PtrFunActive) );
	static ActiveFuncProto(ActFun_STRAIGHT){ return y; }
	static ActiveFuncProto(ActFun_SIGMOID) { return sigmoid(y); }
	static ActiveFuncProto(ActFun_TANH)    { return tanh(y); }
	static ActiveFuncProto(ActFun_TANH2)   { return tanh(y); }	
	
	static PtrFunActive GetActiveFunc(NET_ACTIVE_TYPE type){
		const PtrFunActive funs[NET_ACTIVE_NUM] = { 0,
													ActFun_STRAIGHT,
													ActFun_SIGMOID,
													ActFun_TANH,
													ActFun_TANH2,
												  };
		return funs[type];
	}
	
	typedef DeActiveFuncProto( (*PtrFunDeActive) );
	static DeActiveFuncProto(DeActFun_STRAIGHT) { return 1; }
	static DeActiveFuncProto(DeActFun_SIGMOID)  { return dsigmoid(z); }
	static DeActiveFuncProto(DeActFun_TANH)     { double w = tanh(z); return 1-w*w; }
	static DeActiveFuncProto(DeActFun_TANH2)    { return 1-z*z; }	

	static PtrFunDeActive GetDeActiveFunc(NET_ACTIVE_TYPE type){
		const PtrFunDeActive funs[NET_ACTIVE_NUM] = { 0,
													  DeActFun_STRAIGHT,
													  DeActFun_SIGMOID,
													  DeActFun_TANH,
													  DeActFun_TANH2,
													};
		return funs[type];
	}
};



template<typename DataType>
class MatBase{
public:
	MatBase(){
		m_pData = 0;
		m_nLen  = 0;
		m_bIsRefer = false;	
	}
    ~MatBase(){ Free(); }
public:
    virtual void InitCallBack(){}

    void Create(size_t nLen,DataType val ){
        if(!m_bIsRefer){ SAFE_DELETS(m_pData); }
        m_pData = new DataType[nLen]; m_bIsRefer = false;
        for( size_t i=0; i<nLen; ++i ){ m_pData[i] = val; }
        m_nLen = nLen;
        InitCallBack();
    }
    
    void Clone(MatBase<DataType>& mat){
        if( !m_pData || (m_pData && this->Len() != mat.Len()) ){
            if(!m_bIsRefer){ SAFE_DELETS(m_pData); }
            m_nLen = mat.Len();
            m_pData = new DataType[m_nLen]; m_bIsRefer = false;
        }
        memcpy(m_pData,mat.DataPtr(),m_nLen*sizeof(DataType));
        InitCallBack();
    }
    
    void Refer(DataType *p, size_t len = 0){
        if( len == 0 ){ len = m_nLen; }
        if(!m_bIsRefer){ SAFE_DELETS(m_pData); }
        m_pData = p;
        m_nLen  = len;
        m_bIsRefer = true;
        InitCallBack();
    }
    
    void Refer(MatBase<DataType>& mat){ Refer(mat.DataPtr(),mat.Len()); }
    
    size_t PasteTo(DataType *p, size_t len = 0){
        size_t nRet = 0;
        if( m_pData ){
            if( 0==len ){ len = m_nLen; }
            len  = (len>m_nLen)?m_nLen:len;
            len *= sizeof(DataType);
            memcpy(p,m_pData,len);
            nRet = len;
        }
        return nRet;
    }

    size_t CopyFrom(DataType *p, size_t len = 0){
        size_t nRet = 0;
        if( m_pData ){
            if( 0==len ){ len = m_nLen; }
            len = (len>m_nLen)?m_nLen:len;
            len *= sizeof(DataType);
            memcpy(m_pData,p,len);
            nRet = len;
            InitCallBack();
        }
        return nRet;
    }
    
    void CopyFrom(MatBase<DataType>& mat){
        CopyFrom(mat.DataPtr(),mat.Len());
    }    
     
    void Zero(){
        if( m_pData ){
            memset(m_pData,0,m_nLen*sizeof(DataType));
        }
    }
    
    bool IsValid(){ return 0!=m_pData; }
    
    void Free(){
        if( m_pData ){ 
            if(!m_bIsRefer){ SAFE_DELETS(m_pData); }
            m_nLen = 0;
            m_bIsRefer = false;
        }
    }
    
    DataType* DataPtr() const{ return m_pData; }
    
    size_t Len()  const{ return m_nLen; }
    size_t BLen() const{ return sizeof(DataType)*m_nLen; }
    size_t MLen() const{ return m_bIsRefer?0:BLen(); }
    
    
    void Rand(DataType ValMin, DataType ValMax){
        if( m_pData ){ 
            DataType dist = ValMax-ValMin;
            for( size_t i=0; i<m_nLen; ++i ){ 
                m_pData[i] = ValMin + RAND_ONE*dist;
            }
        }
    }
    
    void Show(const char * name = "", size_t nBrk=0 ){
		/*
        std::cout << name << std::endl;
        size_t j = 0;
        for( size_t i=0; i<m_nLen ; ++i ){
            std::cout << m_pData[i] << " ";
            j++;
            if( nBrk && j==nBrk ){ std::cout << std::endl; }
        }
        std::cout << std::endl;
		*/
	}

public:
    void MatMultScalar(double val){
        for( size_t i=0; i<m_nLen; ++i ){ m_pData[i] *= val; }
    }
    
    void MatScaleShift(double val,double bias){
        for( size_t i=0; i<m_nLen; ++i ){ m_pData[i] *= val; m_pData[i]+=bias; }
    }
    
    void MatSub(MatBase<DataType>& mat ){
        size_t len = MIN( m_nLen, mat.Len() );
        for( size_t i=0; i<len; ++i ){ m_pData[i] -= mat(i); }
    }
    
    void MatAdd(MatBase<DataType>& mat ){
        size_t len = MIN( m_nLen, mat.Len() );
        for( size_t i=0; i<len; ++i ){ m_pData[i] += mat(i); }
    }    
    
    void MatSub(MatBase<DataType>& mat,const double fRat ){
        size_t len = MIN( m_nLen, mat.Len() );
        for( size_t i=0; i<len; ++i ){ m_pData[i] -= mat(i)*fRat; }
    }    

    void MatSub(MatBase<DataType>& matA,MatBase<DataType>& matB ){
        size_t len = m_nLen;
        len = matA.Len()<len?matA.Len():len;
        len = matB.Len()<len?matB.Len():len;
        for( size_t i=0; i<len; ++i ){
            m_pData[i] = matA(i) - matB(i);
        }
    }

    double DotProduct(MatBase<DataType>& mat){
        double sum = 0;
        for( size_t i=0; i<m_nLen; ++i ){ sum += m_pData[i]*mat(i); }
        return sum;
    }
    
   
    
    size_t MaxPos(){
        size_t ret = 0;
        DataType Dmax = m_pData[0];
        for( size_t i=0; i<m_nLen; ++i ){ 
            if( Dmax<m_pData[i] ){ Dmax = m_pData[i]; ret = i; }
        }
        return ret;
    }
    
    double Sum(){
        if(!m_pData){ return 0; }
        double ret = 0;
        for( size_t i=0; i<m_nLen; ++i ){ ret += m_pData[i]; }
        return ret;        
    }

    double Average(){
        if(!m_pData){ return 0; }
        double ret = 0;
        for( size_t i=0; i<m_nLen; ++i ){ ret += m_pData[i]; }
        return ret/m_nLen;        
    }
    
    double AbsNorm(){
        if(!m_pData){ return -1; }
        double ret = 0;
        for( size_t i=0; i<m_nLen; ++i ){
            ret += fabs(m_pData[i]);
        }
        return ret/m_nLen;
    }
    
    double SquareNorm(){
        if(!m_pData){ return -1; }
        double ret = 0;
        double val = 0;
        for( size_t i=0; i<m_nLen; ++i ){
            val = m_pData[i];
            ret += val*val;
        }
        return ret/m_nLen;
    }
public:
    MatBase&  operator*=(DataType val){ if( m_pData ){ for( size_t i=0; i<m_nLen; ++i ){ m_pData[i] *= val;}} return *this; }
    DataType  operator=(DataType val){ if( m_pData ){ for( size_t i=0; i<m_nLen; ++i ){ m_pData[i] = val;}} return val; }
    DataType  operator() (size_t pos) const{ return m_pData[pos]; }
    DataType& operator() (size_t pos){ return m_pData[pos]; }
private:
    DataType* m_pData;
    size_t    m_nLen;
    bool      m_bIsRefer;
};

template<typename DataType>
HQ_INLINE void GetMatMemSize(MatBase<DataType>&Z,MatBase<DataType>&D,MatBase<DataType>& dEdZ){
    dEdZ.MatSub(Z,D);
}

template<typename DataType>
HQ_INLINE void GET_dEdZ_RMS(MatBase<DataType>&Z,MatBase<DataType>&D,MatBase<DataType>& dEdZ){
    dEdZ.MatSub(Z,D);
}

template<typename DataType>
HQ_INLINE void GET_dEdZ_BiCE(MatBase<DataType>&Z,MatBase<DataType>&D,MatBase<DataType>& dEdZ){//Bi Cross Etropy
    size_t len = dEdZ.Len();
    for( size_t i=0; i<len; ++i ){// L= -d*log(z) + -(1-d)*log(1-z)
        dEdZ(i) = -( D(i)/( Z(i)+1e-13 ) - (1-D(i))/(1e-13+1-Z(i)) ); 
    }
}


template<typename DataType>
class Mat1D:public MatBase<DataType>{
public:
    using MatBase<DataType>::Refer;
    using MatBase<DataType>::operator*=;
    using MatBase<DataType>::operator=;
    using MatBase<DataType>::operator();
};

template<typename DataType>
class Mat2D:public MatBase<DataType>{
public:
	Mat2D(){
		m_nRow = 0;
		m_nCol = 0;
		m_Ptr2DPos = 0;	
	}
    ~Mat2D(){ Free2DPos(); }
public:
    virtual void InitCallBack(){ Init2DPos(); }

    void Create(size_t nRow,size_t nCol,DataType val ){
        m_nRow = nRow;
        m_nCol = nCol;
        MatBase<DataType>::Create(m_nRow*m_nCol,val);
    }
    
    void Refer(DataType *p,size_t nRow,size_t nCol){
        m_nRow = nRow;
        m_nCol = nCol;
        MatBase<DataType>::Refer(p,m_nRow*m_nCol);
    }
    
    void Refer(Mat2D<DataType>& mat){
        Refer(mat.DataPtr(),mat.Rows(),mat.Cols());
    }
    
    size_t Rows() const{ return m_nRow; }
    size_t Cols() const{ return m_nCol; }
    void Free2DPos(){ SAFE_DELETS(m_Ptr2DPos); }
    void Init2DPos(){
        Free2DPos();
        m_Ptr2DPos = new DataType *[m_nRow];
        for( size_t i=0; i<m_nRow; ++i ){
            m_Ptr2DPos[i] = this->DataPtr() + i*m_nCol;
        }        
    }

public:
    using MatBase<DataType>::Refer;
    using MatBase<DataType>::operator*=;
    using MatBase<DataType>::operator=;
    using MatBase<DataType>::operator();
    DataType  operator() (size_t nRow,size_t nCol) const{ return m_Ptr2DPos[nRow][nCol]; }
    DataType& operator() (size_t nRow,size_t nCol){ return m_Ptr2DPos[nRow][nCol]; }
private:
    size_t m_nRow;
    size_t m_nCol;
    DataType ** m_Ptr2DPos;
};


template<typename DataType>
class MatBatch{
public:
	MatBatch(){
		m_batchCnt = 0;
		m_batchMax = 1;
		initialed = false;		
	}
private:
    size_t m_batchCnt;
    size_t m_batchMax;
    MatBase<DataType>   m;
    bool                initialed;
public:
    size_t& Max(){ return m_batchMax; }
    void update(MatBase<DataType> &g, bool isUsed = true ){
        if(!isUsed){return;}
        const double   b1 = 0.9;
        const double   b2 = 0.999;
        if(!initialed){
            initialed = true;
            m.Clone(g);
        }else{
            m.MatAdd(g);
        }
        m_batchCnt++;          
    }
    MatBase<DataType> &get(){ return m; }
    bool check(){ return m_batchCnt>m_batchMax; }
    void reset(){ m_batchCnt = 0; m=0; }
};


template<typename DataType>
class MatAdam{
public:
	MatAdam(){
		t  = 1;
		e  = 1e-7;
		at  = 0;
		Thd = 0.5;
		initialed = false;
	}
private:
    double              t;
    double              e;
    double              at;
    double              Thd;
    MatBase<DataType>   v;
    MatBase<DataType>   m;
    MatBase<DataType>   r;
    bool                initialed;
public:
    MatBase<DataType> &get(MatBase<DataType> &g, bool isUsed = true ){
        if(!isUsed){return g;}
        const double   b1 = 0.9;
        const double   b2 = 0.999;
        if(!initialed){
            initialed = true;
            m.Clone(g);
            m = 0;
            v.Clone(m);
            r.Clone(m);
        }
        
        t+=0.1;
        if( Thd>0 && at >Thd ){ at = 0; t=1; }
        else{ at = sqrt( (1-pow(b2,t)) )/(1-pow(b1,t)); }        
        
        double bb1 = 1-b1, bb2 = 1-b2;
        for( size_t i=0; i<v.Len(); ++i ){
            m(i) = m(i)*b1+g(i)*bb1;
            v(i) = b2*v(i) + bb2*g(i)*g(i);
            r(i) = at * m(i)/( sqrt(v(i))+e );
        }
        return r;
    }
};



template<typename DataType>
class ONetData_NN{
public:
	ONetData_NN(){
		LR = 0.002;
		ACT = NET_ACTIVE_NULL;
	}
    double LR;
    NET_ACTIVE_TYPE ACT;
    
    Mat1D<DataType> X;
    Mat1D<DataType> Y;
    Mat1D<DataType> Z;
    Mat2D<DataType> W;
    Mat1D<DataType> B;
    
    Mat1D<DataType> D;
    
    Mat1D<DataType> dEdZ;
    Mat1D<DataType> dZdY;
    Mat1D<DataType> dEdX;
    Mat2D<DataType> dEdW;
    Mat1D<DataType> dEdB;

    MatAdam<DataType> adamW;
    MatAdam<DataType> adamB;
    MatBatch<DataType> batW;
    MatBatch<DataType> batB;

public:
    void UpdateBatch(){
		//W.MatSub( adamW.get(dEdW),LR); 
		//B.MatSub( adamB.get(dEdB),0.3*LR); 
		
        batW.update(dEdW);
        if( batW.check() ){
            W.MatSub( adamW.get( batW.get() ),LR); 
            batW.reset();
        }
        
        batB.update(dEdB);
        if( batB.check() ){
            B.MatSub( adamB.get( batB.get() ),0.3*LR); 
            batB.reset();
        }
		
    }	

    size_t ParamLen(){ return W.BLen()+B.BLen(); }
    size_t ParamGet(unsigned char* p){ 
        size_t pos = 0;
        pos += W.PasteTo( (DataType*)(p+pos) );
        pos += B.PasteTo( (DataType*)(p+pos) );
        return pos;
    }
    size_t ParamSet(unsigned char* p){ 
        size_t pos = 0;
        pos += W.CopyFrom( (DataType*)(p+pos) );
        pos += B.CopyFrom( (DataType*)(p+pos) );
        return pos;
    }
    
    size_t UsedMemFP(){
        return X.MLen()+Y.MLen()+Z.MLen()+W.MLen()+B.MLen();
    }
    size_t UsedMemBP(){
        return D.MLen()+dEdZ.MLen()+dZdY.MLen()+dEdX.MLen()+dEdW.MLen()+dEdB.MLen();
    }
    size_t UsedMem(){
        return UsedMemFP()+UsedMemBP();
    }     
public:
    void MakeFP( size_t XLen, size_t YLen, NET_ACTIVE_TYPE act ){
        ACT = act;
        X.Create(XLen,0);
        Y.Create(YLen,0);
        Z.Create(YLen,0);
        W.Create(YLen,XLen,0);
        B.Create(YLen,0); 
    }
    void Make( size_t XLen, size_t YLen, NET_ACTIVE_TYPE act, double Lr ){
        LR = Lr;
        D.Create(YLen,0); 
        dEdZ.Create(YLen,0);
        dEdX.Create(XLen,0);
        dEdW.Create(YLen,XLen,0);
        dEdB.Create(YLen,0);       
        MakeFP(XLen,YLen,act);       
    }
};

template<typename DataType>
class ONetModel_NN{
public:
    static void FP(ONetData_NN<DataType> &Data){
        FP_Normal(Data);
    }
    static void BP(ONetData_NN<DataType> &Data, bool IsUpdate = true){
        BP_Normal(Data,IsUpdate);
    }
    
    static void FP_Normal(ONetData_NN<DataType> &Data){
        Mat1D<DataType> &X = Data.X;
        Mat1D<DataType> &Y = Data.Y;
        Mat1D<DataType> &Z = Data.Z;
        Mat2D<DataType> &W = Data.W;
        Mat1D<DataType> &B = Data.B;
        
        size_t YLen = Y.Len();
        size_t XLen = X.Len();
        MAKE_ACTFUNC_VAR(active,DataType,Data.ACT);
        
        for( size_t j=0; j<YLen; ++j ){
            double sum = B(j);
            for( size_t i=0; i<XLen; ++i ){ sum += W(j,i)*X(i); }
            Y(j) = sum;
            Z(j) = active(Y(j));
        }
    }
     
    static void BP_Normal(ONetData_NN<DataType> &Data, bool IsUpdate = true){    
        Mat1D<DataType> &X = Data.X;
        Mat1D<DataType> &Y = Data.Y;
        Mat1D<DataType> &Z = Data.Z;
        Mat2D<DataType> &W = Data.W;
        Mat1D<DataType> &B = Data.B;
        Mat1D<DataType> &dEdY = Data.dEdZ;
        Mat1D<DataType> &dEdX = Data.dEdX;
        Mat2D<DataType> &dEdW = Data.dEdW;
        Mat1D<DataType> &dEdB = Data.dEdB;
        
        size_t YLen = Y.Len();
        size_t XLen = X.Len();
        MAKE_DEACTFUNC_VAR(deactive,DataType,Data.ACT);
        
        dEdW.Zero();
        dEdB.Zero();
        dEdX.Zero();
        for( size_t j=0; j<YLen; ++j ){
            double dzdy = deactive(Y(j),Z(j));
            dEdY(j) *= dzdy;
            dEdB(j)  = dEdY(j);
            for( size_t i=0; i<XLen; ++i ){
                dEdW(j,i) = dEdY(j) * X(i);
            }
        }
        
        for( size_t i=0; i<XLen; ++i ){
            double sum = 0;
            for( size_t j=0; j<YLen; ++j ){ sum += dEdY(j) * W(j,i); }
            dEdX(i) = sum;
        }
        
        if( IsUpdate ){
            Data.UpdateBatch();
        }
    }
};

